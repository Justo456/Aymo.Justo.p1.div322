
package practicaparcial;

import Model.*;
import Exceptions.EquipoRepetidoException;

public class PracticaParcial {


    public static void main(String[] args) {
        Centro centro = new Centro();
        
        Equipo e1 = new Aparatos( "sada","papa", 50, NivelUso.ALTA);
        Equipo e2 = new Aparatos("sada","papa", 50,NivelUso.ALTA);
        Equipo e3 = new Instrumentos("Rugby","asdasd","sadasd",NivelUso.MEDIA);
        Equipo e4 = new EquiposEntrenamientos("weqewqe","asdad23",8,NivelUso.BAJA);
        Equipo e5 = new EquiposEntrenamientos("weqewqe22","asdad23a",8,NivelUso.MEDIA);
        
        try {
            centro.agregarEquipo(e1);
            centro.agregarEquipo(e2); 
            centro.agregarEquipo(e3);
            centro.agregarEquipo(e4);
            centro.agregarEquipo(e5);
        } catch (EquipoRepetidoException e) {
            System.out.println(e.getMessage());
        }catch (RuntimeException e){//Esto es para agarrar tmb la excepcion del clima
        }
        
        centro.mostrarEquipos();       
        centro.prepararEquipos();
        System.out.println("________________________________________");
        centro.filtrarPorNivelUso(NivelUso.MEDIA);
       
    }
    
}
