
package Model;

import Interface.Prepararse;

public class Instrumentos extends Equipo implements Prepararse {
    
    private final String tipoDeporte;

    public Instrumentos(String tipoDeporte, String nombre, String sector, NivelUso nivelUso) {
        super(nombre, sector, nivelUso);
        this.tipoDeporte = tipoDeporte;
    }

    
    
    @Override
    public void prepararParaUsoDiario(){
        System.out.println("Aparato %s preparado".formatted(getnombre()));
    }

    @Override
    public String toString() {
        return super.toString() + "pesoMax = " + tipoDeporte;
    }
}
