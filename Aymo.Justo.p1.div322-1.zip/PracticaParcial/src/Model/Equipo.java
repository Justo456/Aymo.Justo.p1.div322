package Model;

import java.util.Objects;

public abstract class Equipo {

    private final String nombre;
    private final String sector;
    private final NivelUso nivelUso;

    public Equipo(String nombre, 
        String sector, NivelUso nivelUso){
        this.nombre = nombre;
        this.sector = sector;
        this.nivelUso = nivelUso;
    }

    public NivelUso getNivelUso() {
        return nivelUso;
    }
    public String getnombre(){
        return this.nombre;
    }

    @Override
    public String toString() {
        return "Equipo: " + "\n" + "nombre = " + nombre + "\n" + "sector = " + sector+ "\n" + "nivelUso = " + nivelUso + "\n";
    }
    
    @Override 
    public boolean equals(Object o){
        if(o == null || !(o instanceof Equipo e)){
            return false;}
        return nombre.equals(e.nombre) && sector.equals(e.sector);
    }
    @Override
    public int hashCode(){
        return Objects.hash(nombre,sector);
    }
    
    
    }

