package Model;

import Exceptions.EquipoRepetidoException;
import Interface.Prepararse;
import java.util.ArrayList;
import java.util.List;

public class Centro {

    private List<Equipo> equipos;

    public Centro() {
        this.equipos = new ArrayList<>();
    }

    public void agregarEquipo(Equipo equipo) {
        validarEquipo(equipo);
        equipos.add(equipo);
    }

    public void mostrarEquipos() {
        System.out.println("MOSTRANDO EQUIPOS");
        System.out.println("-------------------------------------");
        if (equipos.isEmpty()) {
            System.out.println("Lista sin Equipos");
            
        }

        for (Equipo e : equipos) {
            System.out.println(e);
            System.out.println("-------------------------------------");
        }
    }

    public void prepararEquipos() {
        System.out.println("PREPARANDO EQUIPOS");
        System.out.println("-------------------------------------");
        for (Equipo e : equipos) {
            if (e instanceof Prepararse) {
                ((Prepararse) e).prepararParaUsoDiario();
            } else {
                System.out.println("El equipo " + e.getnombre() + ", no requiere preparacion");
            }
        }
    }

    public List<Equipo> filtrarPorNivelUso(NivelUso nivel) {

        List<Equipo> equiposfiltrados = new ArrayList<>();
        for (Equipo e : equipos) {
            if (e.getNivelUso() == nivel) {
                equiposfiltrados.add(e);

            }}
            if (equiposfiltrados.isEmpty()) {
                System.out.println("No hay equipos con ese nivel de uso");
            } else {
                System.out.println("-------------------------------------");
                System.out.println("EQUIPOS FILTRADOS");
                
                for(Equipo e : equiposfiltrados){
                    System.out.println("-------------------------------------");
                    System.out.println(e);
                }
            }

        

        return equiposfiltrados;
    }

    public void validarEquipo(Equipo equipo) throws EquipoRepetidoException {
        if (equipo == null) {
            throw new NullPointerException();
        }
        if (equipos.contains(equipo)) {
            throw new EquipoRepetidoException();
        }

    }
}
