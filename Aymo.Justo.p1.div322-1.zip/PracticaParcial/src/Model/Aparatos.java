
package Model;

import Interface.Prepararse;


public class Aparatos extends Equipo implements Prepararse{
    private  double pesoMax;

    public Aparatos(String nombre, String sector, int par, NivelUso nivelUso) {
        super(nombre, sector, nivelUso);
        this.pesoMax = pesoMax;
    }
    
    @Override
    public void prepararParaUsoDiario(){
        System.out.println("Aparato %s preparado".formatted(getnombre()));
    }

    @Override
    public String toString() {
        return super.toString() + "pesoMax = " + pesoMax;
    }
    
    
    
}
