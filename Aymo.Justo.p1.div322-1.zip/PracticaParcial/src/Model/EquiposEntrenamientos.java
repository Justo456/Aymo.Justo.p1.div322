
package Model;

public class EquiposEntrenamientos extends Equipo {
    private static final int RES_CLIMA_MIN = 1;
    private static final int RES_CLIMA_MAX = 10;
    private int resClima;

    public EquiposEntrenamientos(String nombre, String sector, int resClima, NivelUso nivelUso) {
        super(nombre, sector, nivelUso);
        validarClima(resClima);
        this.resClima = resClima;
    }

    @Override
    public String toString() {
        return super.toString() + "resClima = " + resClima;
    }
    
    private void validarClima(int resClima){
        if (resClima > RES_CLIMA_MAX || resClima < RES_CLIMA_MIN){
            throw new IllegalArgumentException();
        }
    }
    
    
}
