
package Model;


public enum NivelUso {
    BAJA,MEDIA,ALTA
}
