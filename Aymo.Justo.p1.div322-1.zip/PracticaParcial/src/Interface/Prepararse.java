
package Interface;


public interface Prepararse {
    
    void prepararParaUsoDiario();
}
