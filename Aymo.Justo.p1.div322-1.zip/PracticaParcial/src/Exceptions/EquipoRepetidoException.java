
package Exceptions;

public class EquipoRepetidoException extends RuntimeException{
    
    private static final String MSG = "Error. Equipo Repetido";
    
    public EquipoRepetidoException(){
        this(MSG);
    }
    public EquipoRepetidoException(String mensaje){
       super(mensaje);
    }
}
