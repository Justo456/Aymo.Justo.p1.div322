
package aymo.justo.rec1.div322;

import Excepciones.HallazgoRepetidoException;
import Model.Administrador;
import Model.ConstruccionesEstRuin;
import Model.Hallazgo;
import Model.HerramientasAntiguas;
import Model.RestosFosiles;
import Model.TipoConstruccion;
import Model.TipoEpoca;
import java.time.LocalDate;


public class AymoJustoRec1Div322 {

    
    


    public static void main(String[] args) {
        Administrador admin = new Administrador();

        // Crear hallazgos
        Hallazgo h1 = new RestosFosiles("Homo Neanderthalensis", "Esqueleto completo", 
                "Descubrimiento en Cueva A", LocalDate.of(2024, 5, 1), 7, "Cueva A");

        Hallazgo h2 = new HerramientasAntiguas("Piedra", "Cortar carne", 
                "Herramienta paleolítica", LocalDate.of(2024, 6, 12), 6, "Sitio B");

        Hallazgo h3 = new ConstruccionesEstRuin(TipoConstruccion.TEMPLO, TipoEpoca.PRECOLOMBINA, 
                "Ruinas templo andino", LocalDate.of(2023, 11, 5), 5, "Sitio C");

        Hallazgo h4 = new ConstruccionesEstRuin(TipoConstruccion.VIVIENDA, TipoEpoca.MODERNA, 
                "Casa colonial en ruinas", LocalDate.of(2023, 8, 21), 8, "Sitio D");

        Hallazgo repetido = new RestosFosiles("Canis lupus", "Fragmentado","Huesos de lobo", LocalDate.of(2024, 5, 1), 7, "Cueva A"); // Igual a h1

        
        try {
            admin.registrarNuevoHallazgo(h1);
            admin.registrarNuevoHallazgo(h2);
            admin.registrarNuevoHallazgo(h3);
            admin.registrarNuevoHallazgo(h4);
            //admin.registrarNuevoHallazgo(repetido);
        } catch (HallazgoRepetidoException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

        admin.mostrarHallazgos();
        System.out.println("___________________________");
        admin.ejecutarAnalisisLab();
        System.out.println("___________________________");
        admin.ejecutarTareasRest();
        System.out.println("___________________________");
        admin.filtrarHallazgosPorEpoca(TipoEpoca.MODERNA);
        System.out.println("___________________________");
        admin.mostrarHallazgosPorEstado(4);
    }
}

    

