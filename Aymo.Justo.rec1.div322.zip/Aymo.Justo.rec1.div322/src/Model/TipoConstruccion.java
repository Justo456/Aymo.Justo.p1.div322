
package Model;


public enum TipoConstruccion {
    TEMPLO,
    VIVIENDA
}
