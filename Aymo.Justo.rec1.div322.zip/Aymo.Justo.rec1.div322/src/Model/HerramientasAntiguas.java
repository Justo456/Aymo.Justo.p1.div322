
package Model;

import Interfaces.Analizable;
import java.time.LocalDate;


public class HerramientasAntiguas extends Hallazgo implements Analizable {

    private String materialHechas;
    private String usoProbable;

    public HerramientasAntiguas(String materialHechas, String usoProbable, String infoRelacionada, LocalDate fechaDescubrimiento, int estadoConservacion, String sitio) {
        super(infoRelacionada, fechaDescubrimiento, estadoConservacion, sitio);
        this.materialHechas = materialHechas;
        this.usoProbable = usoProbable;
    }
    @Override
    public void analizar(){
        System.out.println("Analizando " + getInfoRelacionada());
    }

    @Override
    public String toString() {
        return super.toString() + "materialHechas = " + materialHechas +"\n"+ "usoProbable = " + usoProbable;
    }
    
    
}
