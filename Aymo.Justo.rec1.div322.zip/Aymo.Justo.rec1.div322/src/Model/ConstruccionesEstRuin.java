
package Model;

import Interfaces.Restaurable;
import java.time.LocalDate;

public class ConstruccionesEstRuin extends Hallazgo implements Restaurable{
    private TipoConstruccion tipoConstruccion;
    private TipoEpoca tipoEpoca;

    public ConstruccionesEstRuin(TipoConstruccion tipoConstruccion, TipoEpoca tipoEpoca, String infoRelacionada, LocalDate fechaDescubrimiento, int estadoConservacion, String sitio) {
        super(infoRelacionada, fechaDescubrimiento, estadoConservacion, sitio);
        this.tipoConstruccion = tipoConstruccion;
        this.tipoEpoca = tipoEpoca;
    }
    
    @Override
    public void restaurar(){
        System.out.println("Restaurando " + getInfoRelacionada());
    }

    @Override
    public String toString() {
        return super.toString()+ "tipoConstruccion = " + tipoConstruccion +"\n"+ "tipoEpoca = " + tipoEpoca;
    }

    public TipoEpoca getTipoEpoca() {
        return tipoEpoca;
    }

    
    
    
    
}
