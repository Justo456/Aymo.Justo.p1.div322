
package Excepciones;


public class HallazgoRepetidoException extends RuntimeException{
    
    public HallazgoRepetidoException(String mensaje){
        super(mensaje);
    }
}
