
package Model;

import Interfaces.Analizable;
import java.time.LocalDate;


public class RestosFosiles extends Hallazgo implements Analizable {

        private String especieDescubierta;
        private String cuerpo;

    public RestosFosiles(String especieDescubierta, String cuerpo, String infoRelacionada, LocalDate fechaDescubrimiento, int estadoConservacion, String sitio) {
        super(infoRelacionada, fechaDescubrimiento, estadoConservacion, sitio);
        this.especieDescubierta = especieDescubierta;
        this.cuerpo = cuerpo;
    }

    
    @Override
    public void analizar(){
        System.out.println("Analizando" + getInfoRelacionada());
    }

    @Override
    public String toString() {
        return super.toString() +"especieDescubierta = " + especieDescubierta +"\n"+ "cuerpo = " + cuerpo;
    }
    
    
        
}
