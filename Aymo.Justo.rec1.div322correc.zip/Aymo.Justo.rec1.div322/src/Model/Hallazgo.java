
package Model;

import java.time.LocalDate;
import java.util.Objects;


public abstract class Hallazgo {

    private String infoRelacionada;
    private LocalDate fechaDescubrimiento;
    private int estadoConservacion;
    private String sitio;
    private static final int EST_CON_MIN = 1;
    private static final int EST_CON_MAX = 10;
    private static final int ID = 50000;

    public Hallazgo(String infoRelacionada, LocalDate fechaDescubrimiento, int estadoConservacion,String sitio) {
        this.infoRelacionada = infoRelacionada;
        this.fechaDescubrimiento = fechaDescubrimiento;
        this.estadoConservacion = estadoConservacion;
        this.sitio = sitio;
    }
    
    private void verificarEstado(int estCons){
        if(estCons > EST_CON_MAX || estCons < EST_CON_MIN){
            throw new RuntimeException("Valor invalido");        }
        
    }

    @Override
    public String toString() {
        return "infoRelacionada = " + infoRelacionada +"\n"+ "fechaDescubrimiento = " + fechaDescubrimiento +"\n"+ "estadoConservacion = " + estadoConservacion+"\n" + "sitio =" + sitio+"\n";
    }

    public String getInfoRelacionada() {
        return infoRelacionada;
    }
    
    @Override 
    public boolean equals(Object o){
        if(o == null || !(o instanceof Hallazgo h)){
            return false;}
        return sitio.equals(h.sitio) && fechaDescubrimiento.equals(h.fechaDescubrimiento);
    }
    @Override
    public int hashCode(){
        return Objects.hash(sitio,fechaDescubrimiento);
    }
    

    public int getEstadoConservacion() {
        return estadoConservacion;
    }
    
    }

