package Model;

import Excepciones.HallazgoRepetidoException;
import Interfaces.Analizable;
import Interfaces.Restaurable;
import java.util.ArrayList;
import java.util.List;

public class Administrador {

    private List<Hallazgo> hallazgos = new ArrayList<>();

    public void registrarNuevoHallazgo(Hallazgo hallazgo) {
        verificarHallazgo(hallazgo);
        hallazgos.add(hallazgo);
    }

    public void verificarHallazgo(Hallazgo hallazgo) {
        if (hallazgo == null) {
            throw new NullPointerException();
        }
        if (hallazgos.contains(hallazgo)) {
            throw new HallazgoRepetidoException("Hallazgo repetido");
        }
    }

    public void mostrarHallazgos() {
        if (hallazgos.isEmpty()) {
            System.out.println("Lista Vacia");
        } else {
            for (Hallazgo h : hallazgos) {
                System.out.println(h);
                System.out.println("----------------------------");
            }
        }
    }

    public void ejecutarAnalisisLab() {
        for (Hallazgo h : hallazgos) {
            if (h instanceof Analizable a) {
                a.analizar();
            }
        }
    }

    public void ejecutarTareasRest() {
        for (Hallazgo h : hallazgos) {
            if (h instanceof Restaurable r) {
                r.restaurar();
            }
        }
    }

    public ArrayList<Hallazgo> filtrarHallazgosPorEpoca(TipoEpoca tipoEpoca) {
        ArrayList<Hallazgo> hallazgosFiltPorEpoca = new ArrayList<>();
           
        for (Hallazgo h : hallazgos) {
            if (h instanceof ConstruccionesEstRuin c) {
                if (c.getTipoEpoca() == tipoEpoca) {
                    hallazgosFiltPorEpoca.add(h);
                }

            }
        if(hallazgosFiltPorEpoca.isEmpty()){
            System.out.println("Lista vacia");
        }else{
            System.out.println(hallazgosFiltPorEpoca);
        }

        }
        return hallazgosFiltPorEpoca;
    }

    public void mostrarHallazgosPorEstado(int estConserv) {
        for (Hallazgo h : hallazgos) {
            if(estConserv == h.getEstadoConservacion()){
                System.out.println(h);
            }
                
        }

    }

}
