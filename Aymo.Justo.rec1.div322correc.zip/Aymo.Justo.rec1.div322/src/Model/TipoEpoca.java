
package Model;


public enum TipoEpoca {
    PRECOLOMBINA,
    COLONIAL,
    MODERNA
}
